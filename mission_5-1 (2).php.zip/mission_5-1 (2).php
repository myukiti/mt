<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>mission_5-1</title>
</head>
<body>
    <form action=""method="post">
        <input type="text" name="name" placeholder="名前" value="<?php if(isset($value1)){echo $value[1];}?>"><br>
        <input type="text" name="comment" placeholder="コメント" value="<?php if(isset($value2)){echo $value[2];}?>"><br>
        <input type="password" name="password" placeholder="パスワード"><br>
        <input type="password" name="check1" placeholder="削除パスワード"><br>
        <input type="password" name="check2" placeholder="編集パスワード"><br>
        <input type="hidden" name="display" value="<?php if(isset($value0)){echo $value0;}?>"><br>
        <input type="submit" name="submit"><br>
        <input type="text" name="delete" placeholder="削除対象番号"><br>
        <input type="submit" value="削除"><br>
        <input type="text" name="edit" placeholder="編集対象番号"><br>
        <input type="submit" value="編集">
    </form>

<?php
    //DB接続
    $dsn = "mysql:dbname=tb221247db;host=localhost";
	$user = "tb-221247";
	$password = "XN3GstCLnm";
	$pdo = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
	
	
	//データ入力
	 if(isset($_POST["name"])) {
         $name = $_POST["name"];
    }
     if(isset($_POST["comment"])){
         $comment = $_POST["comment"];
    }
     if (isset($_POST["password"])) {
         $password = $_POST["password"];
    }
     if (isset($_POST["check1"])) {
         $check1 = $_POST["check1"];
    }
     if (isset($_POST["check2"])) {
         $check2 = $_POST["check2"]; 
    }
     if (isset($_POST["delete"])) {
         $delete = $_POST["delete"];
    }
     $date =date("Y-m-d H:i:s");
     
    //名前・コメント・パスワード入力有→新規or編集
    if(!empty($name) && !empty($comment) && !empty($password)){
    
     if(!empty($POST_["display"])){
         //編集の処理
         
             $id = $POST_["display"]; //変更する投稿番号
             $sql = "UPDATE tbtest SET name=:name,comment=:comment, date=:date, password=:password, WHERE id=:id";
             $stmt = $pdo->prepare($sql);
             $stmt->bindParam(":name", $name, PDO::PARAM_STR);
             $stmt->bindParam(":comment", $comment, PDO::PARAM_STR);
             $stmt->bindParam(":id", $id, PDO::PARAM_INT);
             $stmt->bindParam(":password",$password,PDO::PARAM_STR);
             $stmt->bindParam(":date",$date,PDO::PARAM_STR);
             $stmt->execute();
             
     }else{
         //新規の処理
         
         $sql = "INSERT INTO tbtest (name,comment,date,password) VALUES ('$name','$comment','$date','$password')";
         $stmt = $pdo -> query($sql);
         
     }
     
    }
    
    //削除の処理
    if(!empty($delete)){
        //削除したい投稿番号の取得
        $id = $POST_["delete"];//削除番号
        
        //削除したい投稿のパスワードの取得
        $sql = "SELECT password FROM tbtest WHERE id=:id ";
             $stmt = $pdo->prepare($sql);
             $stmt->bindParam(":id", $id, PDO::PARAM_INT); 
             $stmt->execute();                             
             $results = $stmt->fetchAll(); 
             foreach($results as $row){
                 $password = $row["password"];
             }
             //パスワードが一致したら処理
             if($password == $check1 ){
                 $sql = "delete from tbtest where id=:id";
                 $stmt = $pdo->prepare($sql);
                 $stmt->bindParam(":id", $id, PDO::PARAM_INT);
                 $stmt->execute();
             }
             
    }         
             
    //編集対象番号の取得
    if(!empty($POST_["edit"])){
        $id=$POST_["edit"];
        
        //編集したい投稿のパスワード取得
        $sql="SELECT password FROM tbtest WHERE id=:id";
             $stmt=$pdo->prepare($sql);
             $stmt->bindParam(":id",$id, PDO::PARAM_INT);
             $stmt->execute();
             $results=$stmt->fetchAll();
             foreach($results as $row){
                 $password=$row["password"];
             }
             //パスワードが一致したら処理
             if($password == $check2){
                 $sql="SELECT * FROM tbtest WHERE id=:id";
                 $stmt=$pdo->prepare($sql);
                 $stmt->bindParam(":id",$id,PDO::PARAM_INT);
                 $stmt->execute();
                 $results=$stmt->fetchAll();
                 foreach($results as $row){
                     $value0=$row["id"];
                     $value1=$row["name"];
                     $value2=$row["comment"];
                 }
             }
        
    }
    
    
	$sql = "SELECT * FROM tbtest";
	$stmt = $pdo->query($sql);
	$results = $stmt->fetchAll();
	foreach ($results as $row){
		//$rowの中にはテーブルのカラム名が入る
		echo $row["id"].",";
		echo $row["name"].",";
		echo $row["comment"].",";
		echo $row["date"]."<br>";
	echo "<hr>";
	}
	
	
    ?>

</body>
</html>